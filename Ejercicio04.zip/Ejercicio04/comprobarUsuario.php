<?php
	if ($_GET["user"] === "profesor") {
		echo "existe";
	  } else {
		echo "disponible";
	  }
?>