<nav id="sidebarIzq">
	<h3>Navegación</h3>
	<ul>
		<li><a href="index.php">Inicio</a></li>
		<li><a href="contenido.php">Ver contenido</a></li>
		<li><a href="admin.php">Administrar</a></li>
		<li><a href="registro.php">Registro</a></li>
	</ul>
</nav>